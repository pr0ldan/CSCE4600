package fixtures

import(
	"crypto/md5"
		"strings"
		_ "crypto/md5"
		str "strings"
		strings "strings"  // MATCH /Import alias "strings" is redundant/
		crypto "crypto/md5"
		md5 "crypto/md5"  // MATCH /Import alias "md5" is redundant/
)

