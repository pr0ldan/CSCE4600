package checkers

func _() {
	/*! empty var() block */
	var ()
	/*! empty const() block */
	const ()
	/*! empty type() block */
	type ()
}

/*! empty var() block */
var (
// Comment
)

/*! empty const() block */
const (
/* Comment one */

// Comment two
)

/*! empty type() block */
type ()
