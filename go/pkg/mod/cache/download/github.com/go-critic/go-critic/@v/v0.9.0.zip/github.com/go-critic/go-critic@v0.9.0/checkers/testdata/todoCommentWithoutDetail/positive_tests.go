package checker_test

func singleLineCode() {

	/*! may want to add detail/assignee to this TODO/FIXME/BUG comment */
	// TODO

	/*! may want to add detail/assignee to this TODO/FIXME/BUG comment */
	// FIX

	/*! may want to add detail/assignee to this TODO/FIXME/BUG comment */
	// FIXME

	/*! may want to add detail/assignee to this TODO/FIXME/BUG comment */
	// BUG
}
